from django.apps import AppConfig


class InstructorsConfig(AppConfig):
    name = 'instructors'
